'use strict';
require('dotenv').config({ quiet: true });

function int(name, fallback) {
  const v = parseInt(process.env[name], 10);
  return Number.isFinite(v) ? v : fallback;
}

const isProd = process.env.NODE_ENV === 'production';

const config = {
  isProd,
  port: int('PORT', 3000),
  appUrl: (process.env.APP_URL || 'http://localhost:3000').replace(/\/$/, ''),
  databaseUrl: process.env.DATABASE_URL || 'postgres://timcheck:timcheck@localhost:5432/timcheck',
  databaseSsl: process.env.DATABASE_SSL === 'true',
  sessionSecret: process.env.SESSION_SECRET || '',
  adminEmails: (process.env.ADMIN_EMAILS || '')
    .split(',').map(s => s.trim().toLowerCase()).filter(Boolean),

  // File storage
  storageDriver: process.env.STORAGE_DRIVER || 'local',        // 'local' or 's3'
  storageDir: process.env.STORAGE_DIR || './storage',
  s3: {
    bucket: process.env.S3_BUCKET,
    region: process.env.S3_REGION || 'auto',
    endpoint: process.env.S3_ENDPOINT || undefined,             // set for Cloudflare R2, Backblaze, MinIO
    accessKeyId: process.env.S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
  },

  // Limits
  maxUploadMb: int('MAX_UPLOAD_MB', 10),
  uploadsPerHour: int('UPLOADS_PER_HOUR', 120),
  maxPasteChars: int('MAX_PASTE_CHARS', 200000),
  maxWordsChecked: int('MAX_WORDS_CHECKED', 60000),
  minWords: 20,

  // Background worker
  runWorkerInWeb: process.env.RUN_WORKER_IN_WEB !== 'false',
  workerConcurrency: int('WORKER_CONCURRENCY', 2),
  workerPollMs: int('WORKER_POLL_MS', 1500),
  maxAttempts: 3,
};

if (!config.sessionSecret) {
  if (isProd) {
    console.error('SESSION_SECRET must be set in production. Refusing to start.');
    process.exit(1);
  }
  config.sessionSecret = 'dev-only-secret-change-me';
  console.warn('[config] SESSION_SECRET not set - using an insecure development secret.');
}

module.exports = config;
