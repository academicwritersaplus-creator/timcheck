'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const config = require('../config');
const { requireAuth, asyncRoute } = require('../middleware');

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Too many attempts. Please wait 15 minutes and try again.' },
});

const DUMMY_HASH = bcrypt.hashSync('timing-safe-dummy-password', 12);
const EMAIL_RE =/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;

function validatePassword(pw) {
  const problems = [];
  if (typeof pw !== 'string' || pw.length < 8) problems.push('at least 8 characters');
  if (typeof pw === 'string' && pw.length > 128) problems.push('no more than 128 characters');
  if (!/[A-Za-z]/.test(pw || '')) problems.push('a letter');
  if (!/[0-9]/.test(pw || '')) problems.push('a number');
  return problems;
}

function publicUser(u) {
  return { id: u.id, fullName: u.full_name, email: u.email, role: u.role };
}

function startSession(req, user) {
  return new Promise((resolve, reject) => {
    // New session id on login prevents session-fixation attacks.
    req.session.regenerate(err => {
      if (err) return reject(err);
      req.session.userId = user.id;
      req.session.save(e => (e ? reject(e) : resolve()));
    });
  });
}

router.post('/register', authLimiter, asyncRoute(async (req, res) => {
  const fullName = String(req.body.fullName || '').trim().replace(/\s+/g, ' ');
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = req.body.password;
  const errors = {};
  if (fullName.length < 2 || fullName.length > 100) errors.fullName = 'Enter your full name (2–100 characters).';
  if (!EMAIL_RE.test(email) || email.length > 254) errors.email = 'Enter a valid email address.';
  const pw = validatePassword(password);
  if (pw.length) errors.password = `Password needs ${pw.join(', ')}.`;
  if (Object.keys(errors).length) return res.status(400).json({ error: 'Please fix the highlighted fields.', fields: errors });

  const hash = await bcrypt.hash(password, 12);
  const role = config.adminEmails.includes(email) ? 'admin' : 'user';
  let user;
  try {
    const { rows } = await db.query(
      'INSERT INTO users (full_name, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id, full_name, email, role',
      [fullName, email, hash, role]);
    user = rows[0];
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'An account with this email already exists.', fields: { email: 'This email is already registered.' } });
    throw e;
  }
  await startSession(req, user);
  res.status(201).json({ user: publicUser(user) });
}));

router.post('/login', authLimiter, asyncRoute(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const { rows } = await db.query('SELECT * FROM users WHERE lower(email) = $1', [email]);
  const user = rows[0];
  // Always run bcrypt so response time does not reveal whether the email exists.
  const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) return res.status(401).json({ error: 'Email or password is incorrect.' });
  if (config.adminEmails.includes(email) && user.role !== 'admin') {
    await db.query("UPDATE users SET role = 'admin' WHERE id = $1", [user.id]);
    user.role = 'admin';
  }
  await startSession(req, user);
  res.json({ user: publicUser(user) });
}));

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('timcheck.sid');
    res.json({ ok: true });
  });
});

router.get('/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

module.exports = router;
