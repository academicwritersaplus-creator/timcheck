'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { asyncRoute } = require('../middleware');

const router = express.Router();

const verifyLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Too many checks. Please wait a few minutes.' },
});

// Report verification. Anyone with a reference can confirm that a report
// exists and see its key numbers. No title, owner or text is revealed.
router.get('/verify/:ref', verifyLimiter, asyncRoute(async (req, res) => {
  const ref = String(req.params.ref || '').trim().toUpperCase();
  if (!/^TC-\d{8}-[0-9A-F]{10}$/.test(ref)) return res.status(400).json({ error: 'That does not look like a TimCheck reference (example: TC-20261023-1A2B3C4D5E).' });
  const { rows } = await db.query(
    `SELECT report_ref, created_at, completed_at, word_count, matched_words, similarity, text_sha256
     FROM documents WHERE report_ref = $1 AND status = 'completed'`, [ref]);
  if (!rows[0]) return res.status(404).json({ found: false, error: 'No completed TimCheck report has this reference.' });
  res.json({ found: true, report: rows[0] });
}));

// The comparison collection is public so users can see exactly what they
// are compared against.
router.get('/sources', asyncRoute(async (req, res) => {
  const { rows } = await db.query('SELECT id, title, author, origin, word_count FROM sources ORDER BY title');
  res.json({ items: rows });
}));

router.get('/sources/:id', asyncRoute(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) return res.status(404).json({ error: 'Not found.' });
  const { rows } = await db.query('SELECT id, title, author, origin, word_count, body FROM sources WHERE id = $1', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'Not found.' });
  res.json(rows[0]);
}));

router.get('/health', asyncRoute(async (req, res) => {
  await db.query('SELECT 1');
  res.json({ ok: true });
}));

module.exports = router;
