'use strict';
/*
 * TimCheck similarity engine
 * --------------------------
 * 1. Split text into words (lower-case, punctuation ignored).
 * 2. Make overlapping 5-word "shingles" and hash each one.
 * 3. Look up every shingle hash in the source_shingles index (one SQL query).
 * 4. Verify hash hits word-by-word (so hash collisions can never create a match).
 * 5. Join hits that line up in both texts into continuous passages.
 * 6. Give each submitted word to at most ONE source (longest passage wins),
 *    so overlapping sources are never double counted.
 * 7. Similarity % = matched words / total words * 100.
 *
 * The same text always gives the same result (fully deterministic).
 */
const crypto = require('crypto');

const K = 5; // shingle size in words
const WORD_RE = /[\p{L}\p{N}]+(?:['’][\p{L}\p{N}]+)*/gu;

function tokenize(text) {
  const tokens = [];
  for (const m of text.matchAll(WORD_RE)) {
    tokens.push({
      w: m[0].toLowerCase().replace(/’/g, "'").normalize('NFKC'),
      start: m.index,
      end: m.index + m[0].length,
    });
  }
  return tokens;
}

// 48-bit hash: fits safely in a JavaScript number and a PostgreSQL BIGINT.
function hashShingle(words) {
  return crypto.createHash('md5').update(words.join(' ')).digest().readUIntBE(0, 6);
}

function shingles(tokens) {
  const out = [];
  for (let i = 0; i + K <= tokens.length; i++) {
    out.push(hashShingle(tokens.slice(i, i + K).map(t => t.w)));
  }
  return out;
}

/** Add one source to the comparison collection (inside a transaction client). */
async function indexSource(client, sourceId, body) {
  const hashes = shingles(tokenize(body));
  await client.query('DELETE FROM source_shingles WHERE source_id = $1', [sourceId]);
  const CHUNK = 5000;
  for (let off = 0; off < hashes.length; off += CHUNK) {
    const part = hashes.slice(off, off + CHUNK);
    await client.query(
      `INSERT INTO source_shingles (hash, source_id, pos)
       SELECT h, $2, p FROM unnest($1::bigint[], $3::int[]) AS t(h, p)`,
      [part, sourceId, part.map((_, i) => off + i)],
    );
  }
  return hashes.length;
}

/** Compare text against the whole collection. `db` is a pg Pool or client. */
async function checkText(db, text, { maxWords = 60000 } = {}) {
  let tokens = tokenize(text);
  const truncated = tokens.length > maxWords;
  if (truncated) tokens = tokens.slice(0, maxWords);
  const n = tokens.length;
  const result = { totalWords: n, matchedWords: 0, similarity: 0, sources: [], passages: [], truncated };
  if (n < K) return result;

  const docHashes = shingles(tokens);
  const unique = [...new Set(docHashes)];
  const { rows } = await db.query(
    'SELECT hash, source_id, pos FROM source_shingles WHERE hash = ANY($1::bigint[])',
    [unique],
  );
  if (!rows.length) return result;

  // hash -> list of [sourceId, pos]
  const hits = new Map();
  for (const r of rows) {
    const h = Number(r.hash);
    if (!hits.has(h)) hits.set(h, []);
    hits.get(h).push([r.source_id, r.pos]);
  }

  // Load the candidate sources so every hit can be verified word-by-word.
  const sourceIds = [...new Set(rows.map(r => r.source_id))];
  const srcRes = await db.query(
    'SELECT id, title, author, origin, body FROM sources WHERE id = ANY($1::int[])', [sourceIds]);
  const src = new Map();
  for (const s of srcRes.rows) src.set(s.id, { ...s, tokens: tokenize(s.body) });

  // Collect verified hits grouped by (source, diagonal). On one diagonal the
  // doc position and source position move forward together = same passage.
  const diagonals = new Map();
  docHashes.forEach((h, i) => {
    const list = hits.get(h);
    if (!list) return;
    for (const [sid, j] of list) {
      const st = src.get(sid).tokens;
      let ok = true;
      for (let k = 0; k < K; k++) if (!st[j + k] || st[j + k].w !== tokens[i + k].w) { ok = false; break; }
      if (!ok) continue;
      const key = sid + ':' + (i - j);
      if (!diagonals.has(key)) diagonals.set(key, []);
      diagonals.get(key).push(i);
    }
  });

  // Merge neighbouring hits into runs.
  const runs = [];
  for (const [key, list] of diagonals) {
    const [sid, d] = key.split(':').map(Number);
    list.sort((a, b) => a - b);
    let a = list[0], b = list[0];
    for (let x = 1; x <= list.length; x++) {
      if (x < list.length && list[x] === b + 1) { b = list[x]; continue; }
      runs.push({ sid, d, a, b: b + K - 1, len: b + K - a });
      if (x < list.length) { a = b = list[x]; }
    }
  }
  // Longest first; ties broken by source id then position (deterministic).
  runs.sort((r1, r2) => r2.len - r1.len || r1.sid - r2.sid || r1.a - r2.a);

  const owner = new Int32Array(n);         // 0 = unmatched, otherwise source id
  const srcPos = new Int32Array(n).fill(-1);
  for (const r of runs) {
    let free = 0;
    for (let i = r.a; i <= r.b; i++) if (!owner[i]) free++;
    if (free < K) continue;                 // mostly covered already
    for (let i = r.a; i <= r.b; i++) if (!owner[i]) { owner[i] = r.sid; srcPos[i] = i - r.d; }
  }

  // Build passages: continuous words owned by the same source.
  const perSource = new Map();
  let matched = 0;
  for (let i = 0; i < n;) {
    if (!owner[i]) { i++; continue; }
    const sid = owner[i];
    let j = i;
    while (j + 1 < n && owner[j + 1] === sid) j++;
    const words = j - i + 1;
    matched += words;
    perSource.set(sid, (perSource.get(sid) || 0) + words);
    const st = src.get(sid).tokens, body = src.get(sid).body;
    let s0 = Infinity, s1 = -1;
    for (let x = i; x <= j; x++) { s0 = Math.min(s0, srcPos[x]); s1 = Math.max(s1, srcPos[x]); }
    let excerpt = body.slice(st[s0].start, st[s1].end).replace(/\s+/g, ' ');
    if (excerpt.length > 600) excerpt = excerpt.slice(0, 597) + '...';
    result.passages.push({
      sourceId: sid,
      charStart: tokens[i].start,
      charEnd: tokens[j].end,
      wordCount: words,
      excerpt,
    });
    i = j + 1;
  }

  result.matchedWords = matched;
  result.similarity = Math.round((matched / n) * 1000) / 10;
  result.sources = [...perSource.entries()]
    .map(([sid, words]) => {
      const s = src.get(sid);
      return { sourceId: sid, title: s.title, author: s.author, origin: s.origin, words,
        percent: Math.round((words / n) * 1000) / 10 };
    })
    .sort((x, y) => y.words - x.words || x.sourceId - y.sourceId);
  return result;
}

module.exports = { tokenize, shingles, indexSource, checkText, K };
