'use strict';
/*
 * End-to-end smoke test against a running server.
 *   npm start            (in one terminal)
 *   npm test             (in another; BASE_URL defaults to http://localhost:3000)
 * Creates two throwaway accounts and checks the main features.
 */
const fs = require('fs');
const path = require('path');

const BASE = (process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '');
const FIX = path.join(__dirname, '..', 'test', 'fixtures');
let passed = 0, failed = 0;

function check(name, cond, extra) {
  if (cond) { passed++; console.log(`  PASS  ${name}`); }
  else { failed++; console.log(`  FAIL  ${name}${extra ? '  -> ' + extra : ''}`); }
}

function client() {
  let cookie = '';
  return async function call(p, { method = 'GET', json, form, header = true, raw = false } = {}) {
    const headers = {};
    if (header) headers['X-Requested-With'] = 'TimCheck';
    if (cookie) headers.Cookie = cookie;
    let body;
    if (json) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(json); }
    if (form) body = form;
    const res = await fetch(BASE + p, { method, headers, body, redirect: 'manual' });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    if (raw) return { status: res.status, headers: res.headers, buf: Buffer.from(await res.arrayBuffer()) };
    let data = null; try { data = await res.json(); } catch { /* empty */ }
    return { status: res.status, data };
  };
}

async function waitDone(call, id) {
  for (let i = 0; i < 60; i++) {
    const r = await call(`/api/documents/${id}`);
    if (['completed', 'failed'].includes(r.data.document.status)) return r.data;
    await new Promise(r2 => setTimeout(r2, 500));
  }
  throw new Error('timed out waiting for processing');
}

function fileForm(file, title, type) {
  const fd = new FormData();
  fd.append('title', title);
  fd.append('file', new Blob([fs.readFileSync(path.join(FIX, file))], { type }), file);
  return fd;
}

(async () => {
  const stamp = Date.now();
  const a = client(), b = client();
  console.log(`Testing ${BASE}\n\nAccounts`);
  let r = await a('/api/auth/register', { method: 'POST', json: { fullName: 'Test User A', email: `a${stamp}@example.com`, password: 'short' } });
  check('weak password is rejected', r.status === 400 && r.data.fields.password);
  r = await a('/api/auth/register', { method: 'POST', json: { fullName: 'Test User A', email: `a${stamp}@example.com`, password: 'GoodPass123' } });
  check('register user A', r.status === 201, JSON.stringify(r.data));
  r = await a('/api/auth/register', { method: 'POST', json: { fullName: 'Again', email: `A${stamp}@example.com`, password: 'GoodPass123' } });
  check('duplicate email (any case) is rejected', r.status === 409);
  r = await b('/api/auth/register', { method: 'POST', json: { fullName: 'Test User B', email: `b${stamp}@example.com`, password: 'GoodPass456' } });
  check('register user B', r.status === 201);
  r = await a('/api/auth/logout', { method: 'POST' });
  r = await a('/api/auth/me');
  check('logout ends the session', r.status === 401);
  r = await a('/api/auth/login', { method: 'POST', json: { email: `a${stamp}@example.com`, password: 'wrong-pass1' } });
  check('wrong password is rejected', r.status === 401);
  r = await a('/api/auth/login', { method: 'POST', json: { email: `a${stamp}@example.com`, password: 'GoodPass123' } });
  check('login works', r.status === 200 && r.data.user.fullName === 'Test User A');
  r = await client()('/api/documents');
  check('anonymous users cannot list documents', r.status === 401);
  r = await a('/api/documents', { header: false, method: 'POST', json: {} });
  check('requests without the app header are blocked (CSRF guard)', r.status === 403);

  console.log('\nSubmission and checking');
  const pasted = 'In my assignment I explain that hand hygiene remains the single most effective measure for preventing '
    + 'healthcare-associated infections in hospitals and long-term care facilities. I also think staff need better training '
    + 'and more time on each shift to follow the guidance properly, which my manager agreed with.';
  let fd = new FormData(); fd.append('title', 'Pasted essay'); fd.append('text', pasted);
  r = await a('/api/documents', { method: 'POST', form: fd });
  check('paste text submission accepted', r.status === 201 && r.data.status === 'pending');
  const pasteId = r.data.id;
  let doc = await waitDone(a, pasteId);
  check('paste: completed', doc.document.status === 'completed', doc.document.error_message);
  check('paste: similarity > 0', Number(doc.document.similarity) > 0, doc.document.similarity);
  check('paste: matched the Hand Hygiene sample', doc.sources[0] && /Hand Hygiene/.test(doc.sources[0].title));
  check('paste: highlights point at the right text',
    doc.matches.length && /hand hygiene remains/i.test(doc.document.extracted_text.slice(doc.matches[0].char_start, doc.matches[0].char_end)));
  const sim1 = doc.document.similarity;

  fd = new FormData(); fd.append('title', 'Pasted essay again'); fd.append('text', pasted);
  r = await a('/api/documents', { method: 'POST', form: fd });
  doc = await waitDone(a, r.data.id);
  check('same text gives the same result (reproducible)', doc.document.similarity === sim1);

  r = await a('/api/documents', { method: 'POST', form: fileForm('sample.pdf', 'PDF essay', 'application/pdf') });
  check('PDF upload accepted', r.status === 201);
  const pdfId = r.data.id;
  doc = await waitDone(a, pdfId);
  check('PDF: completed with matches', doc.document.status === 'completed' && doc.matches.length > 0, doc.document.error_message);
  check('PDF: matched the Patient Safety sample', doc.sources.some(s => /Patient Safety/.test(s.title)));

  r = await a('/api/documents', { method: 'POST', form: fileForm('sample.docx', 'Word reflection', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') });
  check('Word upload accepted', r.status === 201);
  doc = await waitDone(a, r.data.id);
  check('Word: completed with two sources', doc.document.status === 'completed' && doc.sources.length === 2, JSON.stringify(doc.sources.map(s => s.title)));

  r = await a('/api/documents', { method: 'POST', form: fileForm('fake.pdf', 'Fake', 'application/pdf') });
  check('a fake PDF is rejected', r.status === 400);
  fd = new FormData(); fd.append('title', 'x'); fd.append('file', new Blob(['hello']), 'notes.doc');
  r = await a('/api/documents', { method: 'POST', form: fd });
  check('old .doc gets a helpful error', r.status === 400 && /docx/.test(r.data.error));
  fd = new FormData(); fd.append('text', 'too short');
  r = await a('/api/documents', { method: 'POST', form: fd });
  check('very short text is rejected', r.status === 400);
  fd = new FormData(); fd.append('file', new Blob([Buffer.concat([Buffer.from('%PDF-'), Buffer.alloc(11 * 1024 * 1024)])]), 'big.pdf');
  r = await a('/api/documents', { method: 'POST', form: fd });
  check('files over the size limit are rejected (413)', r.status === 413);

  console.log('\nReports');
  r = await a(`/api/documents/${pdfId}/report.pdf`, { raw: true });
  check('PDF report downloads', r.status === 200 && r.headers.get('content-type') === 'application/pdf' && r.buf.subarray(0, 4).toString() === '%PDF');
  fs.writeFileSync(path.join(__dirname, '..', 'test', 'last-report.pdf'), r.buf);
  const ref = doc.document.report_ref;
  r = await client()(`/api/verify/${ref}`);
  check('public verification finds the reference', r.status === 200 && r.data.report.similarity === doc.document.similarity);
  check('verification does not reveal the title', r.data && r.data.report && !('title' in r.data.report));
  r = await client()('/api/verify/TC-20990101-0000000000');
  check('unknown reference is reported as not found', r.status === 404);

  console.log('\nAccess control');
  r = await b(`/api/documents/${pasteId}`);
  check("user B cannot open user A's document", r.status === 404);
  r = await b(`/api/documents/${pasteId}/report.pdf`, { raw: true });
  check("user B cannot download user A's report", r.status === 404);
  r = await b(`/api/documents/${pasteId}`, { method: 'DELETE' });
  check("user B cannot delete user A's document", r.status === 404);
  r = await b('/api/documents');
  check("user B's history is empty", r.status === 200 && r.data.total === 0);
  r = await b('/api/admin/documents');
  check('normal users cannot open the admin API', r.status === 403);

  console.log('\nHistory and search');
  r = await a('/api/documents?q=word');
  check('search by title', r.data.total === 1 && r.data.items[0].title === 'Word reflection');
  r = await a(`/api/documents?q=${ref.slice(0, 15)}`);
  check('search by report reference', r.data.total >= 1);
  r = await a('/api/documents?status=completed&pageSize=5');
  check('filter by status', r.data.items.every(d => d.status === 'completed'));
  const today = new Date().toISOString().slice(0, 10);
  r = await a(`/api/documents?from=${today}&to=${today}`);
  check('filter by date', r.data.total === 4);
  r = await a('/api/documents?q=%25');
  check('search treats % literally', r.status === 200 && r.data.total === 0);

  r = await a(`/api/documents/${pasteId}`, { method: 'DELETE' });
  check('owner can delete a document', r.status === 200);
  r = await a(`/api/documents/${pasteId}`);
  check('deleted document is gone', r.status === 404);

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
