'use strict';
/*
 * Load test: submits many documents through the real API and measures how the
 * history pages respond once they are stored.
 *   UPLOADS_PER_HOUR=5000 npm start        (raise the per-user limit for the test)
 *   npm run load-test -- 1200              (number of documents, default 1200)
 * Only run this against a test database.
 */
const fs = require('fs');
const path = require('path');

const BASE = (process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '');
const N = parseInt(process.argv[2], 10) || 1200;
const CONCURRENCY = 20;

const samples = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'sample-sources.json'), 'utf8'));
const sentences = samples.flatMap(s => s.body.split(/(?<=\.)\s+/));
const filler = 'students learned practice reflected community patients during week placement team discussed improved care plan '
  + 'results notes supervisor family service needs review clinic shift goals feedback meeting progress local staff support';
const fw = filler.split(' ');

let seed = 42;
const rand = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };

function makeText(i) {
  const parts = [];
  while (parts.join(' ').split(' ').length < 280) {
    if (rand() < 0.25) parts.push(sentences[Math.floor(rand() * sentences.length)]);
    else parts.push(Array.from({ length: 12 }, () => fw[Math.floor(rand() * fw.length)]).join(' ') + '.');
  }
  return `Document ${i}. ` + parts.join(' ');
}

let cookie = '';
async function call(p, opts = {}) {
  const headers = { 'X-Requested-With': 'TimCheck', ...(cookie ? { Cookie: cookie } : {}) };
  let body = opts.form;
  if (opts.json) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
  const t = performance.now();
  const res = await fetch(BASE + p, { method: opts.method || 'GET', headers, body });
  const ms = performance.now() - t;
  const set = res.headers.get('set-cookie'); if (set) cookie = set.split(';')[0];
  return { status: res.status, data: await res.json().catch(() => null), ms };
}

(async () => {
  const email = `load${Date.now()}@example.com`;
  const reg = await call('/api/auth/register', { method: 'POST', json: { fullName: 'Load Tester', email, password: 'LoadTest123' } });
  if (reg.status !== 201) throw new Error('register failed: ' + JSON.stringify(reg.data));

  console.log(`Submitting ${N} documents...`);
  const t0 = performance.now();
  let next = 0, ok = 0, bad = 0;
  await Promise.all(Array.from({ length: CONCURRENCY }, async () => {
    while (next < N) {
      const i = next++;
      const fd = new FormData();
      fd.append('title', `Load test essay ${String(i).padStart(4, '0')}`);
      fd.append('text', makeText(i));
      const r = await call('/api/documents', { method: 'POST', form: fd });
      if (r.status === 201) ok++; else { bad++; if (bad < 5) console.log('  upload error', r.status, r.data); }
    }
  }));
  console.log(`  accepted ${ok}, rejected ${bad} in ${((performance.now() - t0) / 1000).toFixed(1)} s`);

  console.log('Waiting for the background worker...');
  let stats;
  for (;;) {
    stats = (await call('/api/documents/stats')).data;
    process.stdout.write(`\r  completed ${stats.completed} / ${stats.total}, failed ${stats.failed}   `);
    if (stats.pending + stats.processing === 0) break;
    await new Promise(r => setTimeout(r, 2000));
  }
  console.log(`\n  all processed in ${((performance.now() - t0) / 1000).toFixed(1)} s total`);

  console.log('Timing history queries (milliseconds, including HTTP):');
  const probes = [
    ['first page', '/api/documents?page=1&pageSize=20'],
    ['page 50', '/api/documents?page=50&pageSize=20'],
    ['last page', `/api/documents?page=${Math.ceil(stats.total / 20)}&pageSize=20`],
    ['search title', '/api/documents?q=essay%200999'],
    ['filter status', '/api/documents?status=completed&sort=similarity'],
    ['filter date', `/api/documents?from=${new Date().toISOString().slice(0, 10)}`],
  ];
  for (const [name, p] of probes) {
    const r = await call(p);
    console.log(`  ${name.padEnd(14)} ${String(Math.round(r.ms)).padStart(5)} ms  -> ${r.data.items.length} rows of ${r.data.total}`);
  }
  const r = await call('/api/documents?q=essay%200999');
  const one = await call(`/api/documents/${r.data.items[0].id}`);
  console.log(`  open report    ${String(Math.round(one.ms)).padStart(5)} ms  -> ${one.data.document.similarity}% similarity`);
  console.log(`\nResult: ${stats.completed} completed, ${stats.failed} failed, ${bad} rejected.`);
  process.exit(stats.completed === N && !bad ? 0 : 1);
})().catch(e => { console.error(e); process.exit(1); });
